"""
Core module - Shared utilities and business logic
Independent of API/UI layers
"""