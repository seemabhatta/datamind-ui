"""
Functions module - Core business logic extracted from API routers
These functions can be called directly without HTTP overhead
"""